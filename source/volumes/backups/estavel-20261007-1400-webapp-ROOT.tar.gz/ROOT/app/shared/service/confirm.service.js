// Localization completed
angular.module('headwind-kiosk')
    .factory('confirmModal', function ($uibModal) {
        return {
            getUserConfirmation: function (message, callback, okButtonTextKey) {
                var modalInstance = $uibModal.open({
                    templateUrl: 'app/shared/view/confirm.html?v=h0d675e804a',
                    controller: 'ConfirmController',
                    resolve: {
                        message: function () {
                            return message;
                        },
                        okButtonTextKey: function () {
                            if (okButtonTextKey) {
                                return okButtonTextKey;
                            } else {
                                return 'button.yes';
                            }
                        }
                    }
                });

                modalInstance.result.then(function () {
                    if (callback) callback();
                });
            }
        }
    })
    .controller('ConfirmController', function ($scope, $uibModalInstance, message, okButtonTextKey) {
        $scope.message = message;
        $scope.okButtonTextKey = okButtonTextKey;

        $scope.OK = function () {
            $uibModalInstance.close();
        }
        $scope.cancel = function () {
            $uibModalInstance.dismiss()
        }
    });
