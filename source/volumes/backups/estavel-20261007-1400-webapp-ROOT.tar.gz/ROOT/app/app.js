angular.module('headwind-kiosk',
    ['ngResource', 'ngCookies', 'ui.bootstrap', 'ui.router', 'ngTagsInput', 'ngAnimate', 'ngSanitize',
        'lr.upload', 'colorpicker.module', 'inputDropdown', 'ngIdle', 'chart.js',
        'ui.mask', 'ncy-angular-breadcrumb', 'oc.lazyLoad', 'angularjs-dropdown-multiselect', 'angularCSS'])
    .constant("SUPPORTED_LANGUAGES", {
        'en': 'en_US',
        'en_US': 'en_US',
        'en_UK': 'en_US',
        'en_GB': 'en_US',
        'en_IN': 'en_US',
        'ru': "ru_RU",
        'ru_RU': "ru_RU",
        'fr': 'fr_FR',
        'fr_FR': 'fr_FR',
        'fr_CH': 'fr_FR',
        'fr_BE': 'fr_FR',
        'fr_CA': 'fr_FR',
        'ar': 'ar_AE',
        'ar_AE': 'ar_AE',
        'ar_DZ': 'ar_AE',
        'ar_EG': 'ar_AE',
        'ar_KW': 'ar_AE',
        'ar_PS': 'ar_AE',
        'ar_QA': 'ar_AE',
        'ar_SA': 'ar_AE',
        'es': 'es_ES',
        'es_US': 'es_ES',
        'es_MX': 'es_ES',
        'es_AR': 'es_ES',
        'es_419': 'es_ES',
        'de': 'de_DE',
        'de_DE': 'de_DE',
        'de_AT': 'de_DE',
        'de_CH': 'de_DE',
        'zh_TW': 'zh_TW',
        'zh_HK': 'zh_TW',
        'zh_CN': 'zh_CN',
        'pt': 'pt_PT',
        'pt_PT': 'pt_PT',
        'pt_BR': 'pt_PT',
        'ja_JP': 'ja_JP',
        'tr': 'tr_TR',
        'tr_TR': 'tr_TR',
        'vi': 'vi_VN',
        'vi_VN': 'vi_VN',
        'it': 'it_IT',
        'it_IT': 'it_IT'
    })
    .constant("LOCALIZATION_BUNDLES", [
        'en_US', 'ru_RU', 'fr_FR', 'pt_PT', 'ar_AE', 'es_ES', 'de_DE',
        'zh_TW', 'zh_CN', 'ja_JP', 'tr_TR', 'vi_VN', 'it_IT'])
    .constant("APP_VERSION", "5.39.2") // Update this value on each commit
    .constant("ENGLISH", "en_US")
    .provider('getBrowserLanguage', function (ENGLISH, SUPPORTED_LANGUAGES) {
        this.f = function () {
            var userLang = window.navigator.language || window.navigator.userLanguage;
            if (userLang) {
                userLang = userLang.replace('-', '_');
                if (SUPPORTED_LANGUAGES[userLang]) {
                    userLang = SUPPORTED_LANGUAGES[userLang];
                } else {
                    userLang = ENGLISH;
                }
            } else {
                userLang = ENGLISH;
            }

            return userLang;
        };

        this.$get = function() {
            return this.f;
        };

    })
    .constant("localizeText", function (locale, key) {
        var translations = document.localization[locale] || {};
        var english = document.localization['en_US'] || {};
        var value = translations[key] || english[key];
        if (!value) {
//            console.error('Message key ', key, ' is missing from I18N resource bundle for locale ', locale);
        }
        return value ? value : key;
    })
    .config(['$provide', function ($provide) {
        $provide.decorator('$state', ['$delegate', '$window',
            function ($delegate, $window) {
                var extended = {
                    goNewTab: function (stateName, params) {
                        $window.open(
                            document.location.origin + document.location.pathname + $delegate.href(stateName, params, {absolute: false}), '_blank');
                    }
                };
                angular.extend($delegate, extended);
                return $delegate;
            }]);
    }])
    .config(function ($stateProvider, $locationProvider, $urlRouterProvider, getBrowserLanguageProvider, localizeText) {
        $locationProvider.hashPrefix('');
        $urlRouterProvider.otherwise(function ($injector) {
            var saved = localStorage.getItem('hwmdm.activeTab');
            var tabToUrl = {
                SUMMARY: '/summary', DEVICES: '/', KIOSK: '/kiosk', REMOTE: '/remote',
                GPSMAP: '/gpsMap', CHAT: '/chat', REPORTS: '/reports', GOVERNANCE: '/governance',
                APPS: '/applications', CONFS: '/configurations', FILES: '/files',
                DESIGN: '/designSettings', COMMON: '/commonSettings', USERS: '/users',
                ROLES: '/roles', GROUPS: '/groups', ICONS: '/icons', GENERAL: '/generalSettings',
                EXTENSIONS: '/extensions', INTEGRATIONS: '/integrations', SERVER: '/server'
            };
            return (saved && tabToUrl[saved]) || '/';
        });

        let browserLanguage = getBrowserLanguageProvider.f();

        $stateProvider
            .state('qr', {
                url: '/qr/{qrCode}/{deviceId}',
                templateUrl: 'app/components/main/view/qr.html?v=hux202610071400',
                controller: 'QRController'
            })
            .state('summary', {
                url: '/summary',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: '{{"breadcrumb.summary" | localize}}'
                }

            })
            .state('main', {
                url: '/',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: '{{"breadcrumb.devices" | localize}}'
                }

            })
            .state('remote', {
                url: '/remote',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: '{{"breadcrumb.remote" | localize}}' //label to show in breadcrumbs
                },
                resolve: {
                    openTab: function () {return "REMOTE"}
                }

            })
            .state('kiosk', {
                url: '/kiosk',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: 'Kiosk'
                },
                resolve: {
                    openTab: function () {return "KIOSK"}
                }

            })
            .state('gpsMap', {
                url: '/gpsMap',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: '{{"breadcrumb.gpsmap" | localize}}' //label to show in breadcrumbs
                },
                resolve: {
                    openTab: function () {return "GPSMAP"}
                }

            })
            .state('chat', {
                url: '/chat',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: '{{"breadcrumb.chat" | localize}}' //label to show in breadcrumbs
                },
                resolve: {
                    openTab: function () {return "CHAT"}
                }

            })
            // Reports / Backup & restore / Server defaults / Plugins used to be the
            // only sidebar entries without a state of their own. Opening them left the
            // URL on whatever screen came before, so the browser's Back button had
            // nothing to go back to except the landing state (Devices) - which is what
            // made "back" behave identically on every screen. One state per sidebar
            // entry gives each screen its own history entry.
            .state('reports', {
                url: '/reports',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: 'Reports'
                },
                resolve: {
                    openTab: function () {return "REPORTS"}
                }
            })
            .state('governance', {
                url: '/governance',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: 'Backup & restore'
                },
                resolve: {
                    openTab: function () {return "GOVERNANCE"}
                }
            })
            .state('server', {
                url: '/server',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {label: '{{"nav.server" | localize}}'},
                resolve: {openTab: function () { return 'SERVER'; }}
            })
            .state('generalSettings', {
                url: '/generalSettings',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: 'Server defaults'
                },
                resolve: {
                    openTab: function () {return "GENERAL"}
                }
            })
            .state('extensions', {
                url: '/extensions',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: 'Plugins'
                },
                resolve: {
                    openTab: function () {return "EXTENSIONS"}
                }
            })
            .state('integrations', {
                url: '/integrations',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {label: '{{"nav.integrations" | localize}}'},
                resolve: {openTab: function () { return 'INTEGRATIONS'; }}
            })
            // Telas de plugin abertas pelo menu (PLUGIN_STATES em tabs.controller.js): URL propria, para F5 e Voltar
            .state('webfilterModule', {
                url: '/webfilter?wfTab',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {label: '{{"plugin.webfilter.localization.key.name" | localize}}'},
                resolve: {openTab: function () { return 'plugin-webfilter'; }}
            })
            .state('devicelogModule', {
                url: '/logs',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {label: '{{"plugin.devicelog.localization.key.name" | localize}}'},
                resolve: {openTab: function () { return 'plugin-devicelog'; }}
            })
            .state('auditModule', {
                url: '/acessos',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {label: '{{"plugin.audit.localization.key.name" | localize}}'},
                resolve: {openTab: function () { return 'plugin-audit'; }}
            })
            .state('pushModule', {
                url: '/push',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {label: '{{"plugin.push.localization.key.name" | localize}}'},
                resolve: {openTab: function () { return 'plugin-push'; }}
            })
            .state('deviceinfoModule', {
                url: '/informacao-detalhada',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {label: '{{"plugin.deviceinfo.localization.key.name" | localize}}'},
                resolve: {openTab: function () { return 'plugin-deviceinfo'; }}
            })
            .state('messagingSettingsModule', {
                url: '/mensagens-config',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {label: '{{"plugin.messaging.localization.key.name" | localize}}'},
                resolve: {openTab: function () { return 'plugin-settings-messaging'; }}
            })
            .state('applications', {
                url: '/applications',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: '{{"breadcrumb.applications" | localize}}' //label to show in breadcrumbs
                },
                resolve: {
                    openTab: function () {return "APPS"}
                }
            })
            .state('appVersionsEditor', {
                url: '/application/{id}/versions',
                templateUrl: 'app/components/main/view/applicationVersions.html?v=h7b4cd95319',
                controller: 'ApplicationVersionEditor',
                ncyBreadcrumb: {
                    label: '{{"breadcrumb.application.versions" | localize}}', //label to show in breadcrumbs
                    parent: 'applications',

                }
            })
            .state('configurations', {
                url: '/configurations',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: '{{"breadcrumb.configurations" | localize}}' //label to show in breadcrumbs
                },
                resolve: {
                    openTab: function () {return "CONFS"}
                }
            })
            .state('files', {
                url: '/files',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: '{{"breadcrumb.files" | localize}}' //label to show in breadcrumbs
                },
                resolve: {
                    openTab: function () {return "FILES"}
                }
            })
            .state('designSettings', {
                url: '/designSettings',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: '{{"breadcrumb.default.design" | localize}}' //label to show in breadcrumbs
                },
                resolve: {
                    openTab: function () {return "DESIGN"}
                }
            })
            .state('commonSettings', {
                url: '/commonSettings',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: '{{"breadcrumb.common.settings" | localize}}' //label to show in breadcrumbs
                },
                resolve: {
                    openTab: function () {return "COMMON"}
                }
            })
            // Dead screen: its tab (langSettings) has no template in content.html and no sidebar
            // entry, so the route rendered an empty page. Kept only as a redirect so an
            // old bookmark lands somewhere real instead of on a blank layout.
            .state('langSettings', {
                url: '/langSettings',
                controller: function ($state) {
                    $state.go('commonSettings');
                }
            })
            .state('users', {
                url: '/users',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: '{{"breadcrumb.users" | localize}}' //label to show in breadcrumbs
                },
                resolve: {
                    openTab: function () {return "USERS"}
                }
            })
            .state('roles', {
                url: '/roles',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: '{{"breadcrumb.roles" | localize}}' //label to show in breadcrumbs
                },
                resolve: {
                    openTab: function () {return "ROLES"}
                }
            })
            .state('groups', {
                url: '/groups',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: '{{"breadcrumb.groups" | localize}}' //label to show in breadcrumbs
                },
                resolve: {
                    openTab: function () {return "GROUPS"}
                }
            })
            .state('icons', {
                url: '/icons',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: '{{"tab.icons" | localize}}' //label to show in breadcrumbs
                },
                resolve: {
                    openTab: function () {return "ICONS"}
                }
            })
            // Dead screen: its tab (hints) has no template in content.html and no sidebar
            // entry, so the route rendered an empty page. Kept only as a redirect so an
            // old bookmark lands somewhere real instead of on a blank layout.
            .state('hints', {
                url: '/hints',
                controller: function ($state) {
                    $state.go('summary');
                }
            })
            // Dead screen: its tab (pluginSettings) has no template in content.html and no sidebar
            // entry, so the route rendered an empty page. Kept only as a redirect so an
            // old bookmark lands somewhere real instead of on a blank layout.
            .state('pluginSettings', {
                url: '/pluginSettings',
                controller: function ($state) {
                    $state.go('summary');
                }
            })
            .state('configEditor', {
                url: '/configuration/{id}',
                params: {
                    from: null
                },
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController',
                ncyBreadcrumb: {
                    label: '{{"breadcrumb.config.details" | localize}}',
                    parent: 'configurations'
                },
                resolve: {
                    openTab: function () {return "CONFEDIT"}
                }
            })
            .state('login', {
                url: '/login',
                templateUrl: 'app/components/main/view/login.html?v=h32e5930c2a',
                controller: 'LoginController'
            })
            .state('profile', {
                url: '/profile',
                templateUrl: 'app/components/main/view/content.html?v=hux202610071400',
                controller: 'ShellController'
            })
            .state('updates', {
                url: '/updates',
                controller: function ($state) {
                    $state.go('summary');
                }
            })
            .state('control-panel', {
                url: '/control-panel',
                templateUrl: 'app/components/control-panel/view/panel.html?v=h30e59aa872',
                controller: 'ControlPanelController'
            })
            .state('passwordReset', {
                url: '/passwordReset/{token}',
                templateUrl: 'app/components/main/view/passwordReset.html?v=h44419da27e',
                controller: 'PasswordResetController'
            })
            .state('passwordRecovery', {
                url: '/passwordRecovery',
                templateUrl: 'app/components/main/view/passwordRecovery.html?v=h12658dc04f',
                controller: 'PasswordRecoveryController'
            })
            .state('twoFactorAuth', {
                url: '/twofactor',
                templateUrl: 'app/components/main/view/twoFactorAuth.html?v=h67065d9895',
                controller: 'TwoFactorAuthController'
            })
            .state('signup', {
                url: '/signup',
                templateUrl: 'app/components/main/view/signup.html?v=hefb40716dc',
                controller: 'SignupController'
            })
            .state('signupComplete', {
                url: '/signupComplete/{token}',
                templateUrl: 'app/components/main/view/signupComplete.html?v=hdd7c42bf6b',
                controller: 'SignupCompleteController'
            })
    })

    .config(function ($httpProvider) {
        $httpProvider.interceptors.push(function ($q, $injector) {
            return {
                'responseError': function (rejection) {
                    var $body = angular.element(document.body);
                    var $rootScope = $body.scope().$root;

                    if (rejection.status === 403) {
                        $injector.get('authService').logout();
                        $injector.get('$state').transitionTo('login');
                        $injector.get('hintService').onLogout();
                        $rootScope.$broadcast("aero_USER_LOGOUT");

                        return new Promise(function () {
                        });
                    } else if (rejection.status !== 200 && rejection.status !== 204) {
                        $rootScope.$broadcast('RELOAD_MESSAGE');
                    }

                    return $q.reject(rejection);
                }
            };
        });

        $httpProvider.defaults.cache = false;
        if (!$httpProvider.defaults.headers.get)
            $httpProvider.defaults.headers.get = {};

        $httpProvider.defaults.headers.get['If-Modified-Since'] = 'Thu, 01 Jan 1970 00:00:00 GMT';
        $httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
    })
    .constant("SUPPORTED_LIBS", [
        {
            name: 'leaflet',
            files: [
                'ext/leaflet-1.5.1/leaflet.js'
            ],
            styles: [
                'ext/leaflet-1.5.1/leaflet.css'
            ]
        },
        {
            name: 'leaflet.markercluster',
            files: [
                'ext/leaflet.markercluster-1.4.1/leaflet.markercluster.js'
            ],
            styles: [
                'ext/leaflet.markercluster-1.4.1/MarkerCluster.css'
            ]
        },
        {
            name: 'leaflet.markercluster.layersupport',
            files: [
                'ext/leaflet.markercluster-1.4.1/leaflet.markercluster.layersupport.js'
            ]
        }
    ])
    .config(['$ocLazyLoadProvider', 'SUPPORTED_LIBS', function($ocLazyLoadProvider, SUPPORTED_LIBS) {
        $ocLazyLoadProvider.config({
            events: true,
            modules: angular.copy(SUPPORTED_LIBS, [])
        });
    }])
    .config(function($cssProvider) {
        angular.extend($cssProvider.defaults, {
            container: 'head',
            method: 'append',
            persist: false,
            preload: false,
            bustCache: false
        });
    })
    .factory("externalLibLoader", function ($rootScope, $ocLazyLoad, $timeout, $css, SUPPORTED_LIBS) {

        var libs = {};
        SUPPORTED_LIBS.forEach(function (lib) {
            libs[lib.name] = angular.extend(angular.copy(lib, {}), {loadedFiles: [], loading: false, loaded: false})
        });

        var noOpLoader = function (libId) {
            console.log("External library has been loaded already: ", libId);
            return new Promise(function(resolve) {
                resolve();
            })
        };

        var getLoader = function (libId) {
            var loader = noOpLoader;

            if (isSupported(libId)) {
                var library = libs[libId];

                if (!library.loaded) {
                    if (!library.loading) {
                        library.loading = true;

                        if (library.styles && library.styles.length > 0) {
                            library.styles.forEach(function (style) {
                                $css.bind(style, $rootScope);
                            });
                        }
                        
                        loader = function () {
                            console.log("Loading external library: ", libId, " ...");

                            return new Promise(function (resolve) {
                                var listenerRemove = $rootScope.$on('ocLazyLoad.fileLoaded', function (e, url) {
                                    if (library.files.indexOf(url) >= 0) {
                                        console.log('Loaded external library: ', url);
                                        
                                        if (library.loadedFiles.indexOf(url) < 0) {
                                            library.loadedFiles.push(url);
                                        }
                                        if (library.files.length === library.loadedFiles.length) {
                                            library.loaded = true;
                                            library.loading = false;
                                            resolve();
                                            listenerRemove();
                                        }
                                    }
                                });

                                $ocLazyLoad.load(libId);
                            })
                        }
                    } else {
                        loader = function () {
                            console.log("Waiting for the library to load: " + libId);
                            return new Promise(function (resolve) {
                                var wait = function () {
                                    if (library.loaded) {
                                        console.log("Awaited library has been loaded: " + libId);
                                        resolve();
                                    } else {
                                        $timeout(wait, 100);
                                    }
                                };

                                $timeout(wait, 100);
                            });
                        }
                    }
                }
            }

            return {
                load: function () {
                    return loader(libId);
                }
            }
        };

        var isSupported = function (libId) {
            return libs.hasOwnProperty(libId);
        };

        return {
            getLoader: getLoader,
            isLibrarySupported: isSupported
        }
    })
    .run(function ($rootScope, $state, $stateParams, authService, pluginService, $ocLazyLoad, localization, hintService,
                   $window, $transitions, rebranding, Idle) {
        $rootScope.$state = $state;
        $rootScope.$stateParams = $stateParams;

        var initIdleLogout = function() {
            var user = authService.getUser();
            if (user.idleLogout) {
                Idle.setIdle(user.idleLogout);
                Idle.setTimeout(10);
                Idle.watch();
            } else {
                Idle.unwatch();
            }
        };

        if (authService.isLoggedIn()) {
            hintService.init();
            initIdleLogout();
        }

        pluginService.getRegisteredPlugins(function (response) {
            if (response.status === 'OK') {
                if (response.data) {
                    response.data.forEach(function (plugin) {
                        if (!plugin.javascriptModuleFile) {
                            return;
                        }
                        try {
                            $ocLazyLoad.load(plugin.javascriptModuleFile);
                        } catch (e) {
                            console.error('Failed to load plugin module', e);
                        }
                    });
                }
            }
        });

        $window.document.title = localization.localize('app.title').replace('${appName}', "MDM");
        rebranding.query(function(value) {
            $window.document.title = localization.localize('app.title').replace('${appName}', value.appName);
        });

        $rootScope.$on('aero_LANGUAGE_SETTINGS_UPDATED', function (event, newSettings) {
            localization.onLangSettingsChange(newSettings, $rootScope);
        });

        $rootScope.$on('aero_LOCALE_CHANGED', function () {
            $window.document.title = localization.localize('app.title').replace('${appName}', "MDM");
            rebranding.query(function(value) {
                $window.document.title = localization.localize('app.title').replace('${appName}', value.appName);
            });
        });

        $rootScope.$on('aero_USER_AUTHENTICATED', function () {
            localization.onLogin($rootScope);
            hintService.onLogin();
            initIdleLogout();
        });

        // $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
        //     hintService.onStateChangeSuccess();
        // });

        $rootScope.$on('$cssAdd', function (a, b, c) {
            console.log('$cssAdd:', a, b, c);
        });

        $transitions.onStart({ }, function(trans) {
            hintService.onStateChangeStart();

            if (trans.to().name !== 'passwordRecovery' &&
                trans.to().name !== 'signup' &&
                trans.to().name !== 'signupComplete' &&
                trans.to().name !== 'passwordReset' &&
                trans.to().name !== 'qr') {
                if (!authService.isLoggedIn() && trans.to().name !== 'login') {
                    hintService.onLogout();
                    return trans.router.stateService.target('login');
                }
            }

            if (authService.isLoggedIn() && trans.to().name === 'login') {
                return trans.router.stateService.target('main');
            }
        });
    });
